Ambire signer v4 case and battery pack

case.3mf     all four parts laid out for printing: the shell on its back, the bezel face
             down, the tray on its top face, the door flat
shell.stl    back shell (standoffs, locating pins, the screw hole, the camera window, the
             recess the pack's board nests in, two magnet pockets)
bezel.stl    front bezel (the screen sits in it; the screw threads into its chin)
tray.stl     the battery pack's body: the pack's board sits on its walls
door.stl     the pack's bottom: slides in from the right-hand edge (seen from the back, the left)
*.step       the same parts for CAD

Assembly: stick the screen to the board's front face with 0.3 mm foam tape, its
ribbons through the board's slots into their connectors. Lay the board in the shell (its
two top holes onto the pins). Hook the bezel's top edge under the shell's top lip, swing
it down over the screen, then the M2 pan-head screw from the back.

The pack: four 6 x 2 mm N52 disc magnets. Glue two into the pockets inside the shell's
back and two onto the marked circles on the pack board's inner face, with the poles
opposite: test each pair before the glue sets, the pack must snap on one way round and
push off the other. Glue the pack board onto the tray's walls, gold pads out. Two AAA
cells go in through the door, as marked on the board. The pack snaps onto the device's
back with its board in the recess; the cells charge over USB in the device.

Print the shell on its back, the bezel face down, the tray on its top face and the door
flat: none needs supports. On a filament printer the recess in the shell's back prints
as a ~28 mm bridge; a resin print does not have that problem.

Units are millimetres. Print in see-through resin or PETG (ice blue, orange, purple or
clear). The fits are set for an FDM printer with a 0.4 mm nozzle (0.2 mm between parts
that slide or snap). These files have not been printed yet.
