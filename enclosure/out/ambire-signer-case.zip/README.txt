Ambire signer v3 case

case.3mf     shell and bezel laid out for printing: the shell on its back, the bezel face down
shell.stl    back shell (standoffs, locating pins, the screw hole, the camera window, the
             opening the AAA cell stands through)
bezel.stl    front bezel (the screen sits in it; the screw threads into its chin)
cover.stl    optional cell cover: slides into the cell's opening from the right-hand
             edge (seen from the back, the left) until it stops
*.step       the same parts for CAD

Assembly: stick the screen to the board's front face with 0.3 mm foam tape, its
ribbons through the board's slots into their connectors. Press an AAA cell into its
clips on the board's back. Lay the board in the shell (its two top holes onto the
pins). Hook the bezel's top edge under the shell's top lip, swing it down over the
screen, then the M2 pan-head screw from the back. The camera and the cell stand
out of the back; slide the cover on over the cell if you want it covered. The cell
charges over USB in the device.

Print the shell on its back and the bezel face down, the cover standing on its end:
none of them needs supports.

Units are millimetres. Print in see-through resin or PETG (ice blue, orange,
purple or clear). Nothing has been test-printed yet: the screw bosses, the top hook
and the joystick's opening may need adjusting.
