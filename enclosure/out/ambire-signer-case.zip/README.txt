Ambire signer proto 0 case

case.3mf     both parts laid out for printing: the shell on its back, the bezel face down
shell.stl    back shell (the board screws onto its four posts, M2 self-tapping)
bezel.stl    front bezel (snaps onto the shell)
*.step       the same parts for CAD

Units are millimetres. Print in translucent or clear resin or PETG. Nothing has been
test-printed yet: the snap fit and the power-button tab may need adjusting.
