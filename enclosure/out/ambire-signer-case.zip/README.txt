Ambire signer proto 1 case

case.3mf     both parts laid out for printing: the shell on its back, the bezel face down
shell.stl    back shell (standoffs, locating pins, the screw holes, the camera window,
             the hump over the AAA cell)
bezel.stl    front bezel (the screen sits in it; the screws thread into its chin)
*.step       the same parts for CAD

Assembly: stick the screen to the board's front face with 0.3 mm foam tape, its
ribbons through the board's slots into their connectors. Press an AAA cell into its
clips on the board's back. Lay the board in the shell (its two top holes onto the
pins). Hook the bezel's top edge under the shell's top lip, swing it down over the
screen, then the M2 pan-head screws from the back. The camera stands out of the
back; the cell sits under the hump. To change the cell, take the screws out and lift
the shell off: the cell stays on the board.

Print the bezel face down: it needs no supports. The shell rests on its hump, so the
rest of its back needs supports (or print it in resin, which supports it anyway).

Units are millimetres. Print in see-through resin or PETG (ice blue, orange,
purple or clear). Nothing has been test-printed yet: the screw bosses, the top hook
and the joystick's opening may need adjusting.
