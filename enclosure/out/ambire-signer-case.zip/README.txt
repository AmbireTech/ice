Ambire signer proto 0 case

case.3mf     both parts laid out for printing: the shell on its back, the bezel face down
shell.stl    back shell (four standoffs; the screw heads sit flush in its back face)
bezel.stl    front bezel (the screen sits in it; the screws thread into its bosses)

Assembly: screen face down into the bezel, battery onto the screen, board onto the
bezel's bosses, shell over it, then 4x M2 pan-head screws (length below) from the
back. Print the shell on its back and the bezel face down: neither needs supports.
*.step       the same parts for CAD

Units are millimetres. Print in translucent or clear resin or PETG. Nothing has been
test-printed yet: the screw bosses and the power-button tab may need adjusting.
