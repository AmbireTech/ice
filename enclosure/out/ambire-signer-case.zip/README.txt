Ambire signer proto 1 case

case.3mf     both parts laid out for printing: the shell on its back, the bezel face down
shell.stl    back shell (standoffs, two locating pins, two screw holes, the camera window)
bezel.stl    front bezel (the screen sits in it; the screws thread into its chin)
*.step       the same parts for CAD

Assembly: stick the screen to the board's front face with 0.3 mm foam tape, its
ribbons through the board's slots into their connectors. Lay the board in the shell
(its two top holes onto the pins). Hook the bezel's top edge under the shell's top
lip, swing it down over the screen, then 2x M2 pan-head screws (length below) from
the back. Last, press an AAA cell into its clips from the front: the cell and the
camera both stand out of the case. Print the shell on its back and the bezel face
down: neither needs supports.

Units are millimetres. Print in see-through resin or PETG (ice blue, orange,
purple or clear). Nothing has been test-printed yet: the screw bosses, the top hook
and the joystick's opening may need adjusting.
