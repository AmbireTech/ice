Ambire signer v4 case and battery pack

case.3mf     the three parts laid out for printing: the shell on its back, the bezel face
             down, the tray on its top face
shell.stl    back shell (standoffs, locating pins, the screw hole, the camera window, the
             shallow recess the pack's board sits in, the connector's window, two magnet pockets)
bezel.stl    front bezel (the screen sits in it; the screw threads into its chin)
tray.stl     the battery pack's frame: the pack's board sits in its top, the cells show underneath
*.step       the same parts for CAD

Assembly: stick the screen to the board's front face with 0.3 mm foam tape, its
ribbons through the board's slots into their connectors. Lay the board in the shell (its
two top holes onto the pins). Hook the bezel's top edge under the shell's top lip, swing
it down over the screen, then the M2 pan-head screw from the back.

The pack: two 8 x 1.5 mm N52 disc magnets glue into the pockets inside the shell's back,
two 6 x 2 mm ones onto the marked circles on the pack board's inner face, poles opposite:
test each pair before the glue sets, the pack must snap on one way round and push off the
other. Glue the pack board into the tray's top, the magnetic connector out. Two AAA cells
press into the clips from underneath, as marked on the board. The pack snaps onto the
back below the camera, the connector into its window; the cells charge over USB in the
device.

Print the shell on its back, the bezel face down and the tray on its top face: none needs
supports. Units are millimetres. Print in see-through resin or PETG (ice blue, orange,
purple or clear). The fits are set for an FDM printer with a 0.4 mm nozzle (0.2 mm
between parts that slide or snap). These files have not been printed yet.
