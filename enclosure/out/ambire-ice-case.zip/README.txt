Ambire Ice v4 case

case.3mf     the three parts laid out for printing (PrusaSlicer, Lychee, CHITUBOX):
             the shell on its back, the bezel face down, the joystick's cap on its pad.
             The shell and the bezel need no supports.
case.stl     the same layout for any other slicer (split it into parts to place them yourself)
halves.stl   the shell and the bezel alone, laid out the same way (halves.pwsz: sliced for the
             Anycubic Photon Mono M7 Pro)

The parts:
  shell      back shell (standoffs, locating pins, the screw hole, the camera window, the
             window the pack's connector drops through)
  bezel      front bezel (the screen sits in it; the screw threads into its chin)
  joycap     the joystick's cap: print it upside down, its flat pad on the plate; press it straight
             onto the stem (a drop of glue if it comes loose)

The airgap switch is worked through the opening in the left wall, with a fingernail or a
pen tip.

Assembly: stick the screen to the board's front face with 0.3 mm foam tape, its
ribbons through the board's slots into their connectors. Lay the board in the shell (its
two top holes onto the pins). Hook the bezel's top edge under the shell's top lip, swing
it down over the screen, then the M2 pan-head screw from the back.

Units are millimetres. Print in clear resin on a resin (MSLA) printer, each part
directly on the build plate as laid out, no supports and no raft. The fits are set for
resin at calibrated exposure (0.1 mm between parts that slide or snap); a filament
printer needs 0.2 mm. These files have not been printed yet.
