Ambire Ice v4 case and battery pack

case.3mf     the six parts laid out for printing: the shell on its back, the bezel face
             down, the tray on its top face, the pack's frame on its face, the joystick's
             cap on its sleeve, the airgap slider on its flange
shell.stl    back shell (standoffs, locating pins, the screw hole, the camera window, the
             window the pack's connector drops through)
bezel.stl    front bezel (the screen sits in it; the screw threads into its chin)
tray.stl     the battery pack's tray: the pack's board sits in its top, the cells show underneath
frame.stl    the frame round the pack's contacts: it holds the two magnets, and its tab
             keys the pack in the back's window
joycap.stl   the joystick's cap: print it standing on its sleeve, dish up; press it straight
             onto the stem (a drop of glue if it comes loose)
airslider.stl  the airgap switch's slider: print it on its flange, grip up; it goes into its
             window in the shell's west wall from inside, grip out, before the board
*.step       the same parts for CAD

Assembly: push the airgap slider into its window in the shell's west wall from inside,
grip out. Stick the screen to the board's front face with 0.3 mm foam tape, its
ribbons through the board's slots into their connectors. Lay the board in the shell (its
two top holes onto the pins). Hook the bezel's top edge under the shell's top lip, swing
it down over the screen, then the M2 pan-head screw from the back.

The pack: the frame and the magnets are glued hard to the pack board with epoxy (not
superglue, which holds poorly on PETG); the pegs only locate the frame while it cures.
Spread epoxy over the frame's whole underside, press its pegs into the two holes beside
the pack board's spring pins (tab north) and wipe off what squeezes into the pins' slot.
Put a drop of epoxy into each magnet's pocket and press a magnet in, hard, down onto the
board (a flat tool: the pocket's three ribs crush round it): either pole up, they hold on
steel. Let it cure before the pack goes on the device. Glue the pack
board into the tray's top, the frame out. Two AAA cells press into the clips from
underneath, as marked on the board. The pack snaps onto the back below the camera, the
frame through the window, the pins on the pads on the device's board, the magnets on the
steel spacers beside them; the cells charge over USB in the device.

Print the shell on its back, the bezel face down, the tray on its top face and the frame on
its face: none needs
supports. Units are millimetres. Print in see-through resin or PETG (ice blue, orange,
purple or clear). The fits are set for an FDM printer with a 0.4 mm nozzle (0.2 mm
between parts that slide or snap). These files have not been printed yet.
