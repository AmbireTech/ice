Ambire Ice v4 case

case.3mf     the four parts laid out for printing (Bambu Studio, OrcaSlicer, PrusaSlicer):
             the shell on its back, the bezel face down, the joystick's cap on its sleeve,
             the airgap slider on its flange. The shell and the bezel need no supports.
case.stl     the same layout for any other slicer (split it into parts to place them yourself)

The parts:
  shell      back shell (standoffs, locating pins, the screw hole, the camera window, the
             window the pack's connector drops through)
  bezel      front bezel (the screen sits in it; the screw threads into its chin)
  joycap     the joystick's cap: print it standing on its sleeve, dish up; press it straight
             onto the stem (a drop of glue if it comes loose)
  airslider  the airgap switch's slider: print it on its flange, grip up; it goes into its
             window in the shell's west wall from inside, grip out, before the board

Assembly: push the airgap slider into its window in the shell's west wall from inside,
grip out. Stick the screen to the board's front face with 0.3 mm foam tape, its
ribbons through the board's slots into their connectors. Lay the board in the shell (its
two top holes onto the pins). Hook the bezel's top edge under the shell's top lip, swing
it down over the screen, then the M2 pan-head screw from the back.

Units are millimetres. Print in see-through resin or PETG (ice blue, orange,
purple or clear). The fits are set for an FDM printer with a 0.4 mm nozzle (0.2 mm
between parts that slide or snap). These files have not been printed yet.
