Ambire Ice v4 battery pack tray

battery-tray.3mf  the pack's tray laid out for printing on its top face; it needs no supports
battery-tray.stl  the same layout for any other slicer

The part:
  tray       the battery pack's tray: the pack's board sits in its top, the cells show underneath

Glue the pack board into the tray's top, the magnetic connector out. Two AAA cells press
into the clips from underneath, as marked on the board. The pack snaps onto the back below
the camera, the connector through the window (its tab keys it), its pins on the pads on the
device's board, its magnets on the steel spacers beside them; the cells charge over USB in
the device.

Units are millimetres. Print in clear resin on a resin (MSLA) printer, each part
directly on the build plate as laid out, no supports and no raft. The fits are set for
resin at calibrated exposure (0.1 mm between parts that slide or snap); a filament
printer needs 0.2 mm. These files have not been printed yet.
