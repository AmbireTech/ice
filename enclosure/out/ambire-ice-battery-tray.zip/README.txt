Ambire Ice v4 battery pack tray and frame

battery-tray.3mf  the pack's two parts laid out for printing: the tray on its top face, the
                  frame on its face (pegs up); neither needs supports
battery-tray.stl  the same layout for any other slicer

The parts:
  tray       the battery pack's tray: the pack's board sits in its top, the cells show underneath
  frame      the frame round the pack's contacts: it holds the two magnets, and its tab
             keys the pack in the back's window

The frame and the magnets are glued hard to the pack board with epoxy (not superglue,
which holds poorly on PETG); the pegs only locate the frame while it cures. Spread epoxy
over the frame's whole underside, press its pegs into the two holes beside the pack
board's spring pins (tab east) and wipe off what squeezes into the pins' slot. Put a drop
of epoxy into each magnet's pocket and press a magnet in, hard, down onto the board (a
flat tool: the pocket's three ribs crush round it): either pole up, they hold on steel.
Let it cure before the pack goes on the device. Glue the pack board into the tray's top,
the frame out. Two AAA cells press into the clips from underneath, as marked on the
board. The pack snaps onto the back below the camera, the frame through the window, the
pins on the pads on the device's board, the magnets on the steel spacers beside them; the
cells charge over USB in the device.

Units are millimetres. Print in clear resin on a resin (MSLA) printer, each part
directly on the build plate as laid out, no supports and no raft. The fits are set for
resin at calibrated exposure (0.1 mm between parts that slide or snap); a filament
printer needs 0.2 mm. These files have not been printed yet.
