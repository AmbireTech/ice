Ambire Ice v4 battery pack tray

battery-tray.3mf  the battery pack's frame on its top face, ready to print (no supports)
battery-tray.stl  the same for any other slicer

Glue the pack board into the tray's top, its magnetic connector out. Two AAA cells press
into the clips from underneath, as marked on the board. The pack snaps onto the back
below the camera, its connector through the window onto the receptacle on the device's
board, whose magnets hold it; the cells charge over USB in the device.

Units are millimetres. Print in see-through resin or PETG (ice blue, orange,
purple or clear). The fits are set for an FDM printer with a 0.4 mm nozzle (0.2 mm
between parts that slide or snap). These files have not been printed yet.
