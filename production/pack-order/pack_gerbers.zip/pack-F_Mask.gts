%TF.GenerationSoftware,KiCad,Pcbnew,10.0.4*%
%TF.CreationDate,2026-10-28T16:38:58+02:00*%
%TF.ProjectId,pack,7061636b-2e6b-4696-9361-645f70636258,v4*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.4) date 2026-10-28 16:38:58*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,1.500000*%
G04 APERTURE END LIST*
D10*
%TO.C,J_PACK*%
X43600000Y17850000D03*
X43600000Y15350000D03*
X43600000Y12850000D03*
X43600000Y10350000D03*
%TD*%
M02*
